const colors = require('tailwindcss/colors');

module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}', // Ensure Tailwind scans all your files
  ],
  theme: {
    extend: {
      colors: {
        alabaster: {
          DEFAULT: '#f1f2eb',
          100: '#373a26',
          200: '#6e744c',
          300: '#a0a778',
          400: '#c9cdb2',
          500: '#f1f2eb',
          600: '#f5f5f0',
          700: '#f7f8f4',
          800: '#fafaf8',
          900: '#fcfdfb',
        },
        timberwolf: {
          DEFAULT: '#d8dad3',
          100: '#2d2f27',
          200: '#595d4e',
          300: '#858c75',
          400: '#afb3a4',
          500: '#d8dad3',
          600: '#e0e1db',
          700: '#e7e9e4',
          800: '#eff0ed',
          900: '#f7f8f6',
        },
        cambridge_blue: {
          DEFAULT: '#a4c2a5',
          100: '#1d2b1d',
          200: '#39563a',
          300: '#568157',
          400: '#78a57a',
          500: '#a4c2a5',
          600: '#b6ceb6',
          700: '#c8dac9',
          800: '#dae7db',
          900: '#edf3ed',
        },
        ebony: {
          DEFAULT: '#566246',
          100: '#11140e',
          200: '#22271c',
          300: '#343b2a',
          400: '#454f38',
          500: '#566246',
          600: '#798a62',
          700: '#9baa87',
          800: '#bcc6af',
          900: '#dee3d7',
        },
        davys_gray: {
          DEFAULT: '#4a4a48',
          100: '#0f0f0f',
          200: '#1e1e1d',
          300: '#2d2d2c',
          400: '#3c3c3b',
          500: '#4a4a48',
          600: '#6f6f6d',
          700: '#939391',
          800: '#b7b7b6',
          900: '#dbdbda',
        },
      },
    },
  },
  plugins: [],
};