import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Menu from './components/Menu';
import NarratorsPage from './pages/NarratorsPage';
import BookPage from './pages/BookPage';
import ReferencePage from './pages/ReferencePage';
import Home from './pages/Home';
import Query from './pages/Query';
import HadithPage from './pages/HadithPage';
import NarratorDetailsPage from './pages/Narrator';

const App = () => {
  return (
    <Router>
      <div>
        <Menu /> {/* Render the Menu component */}
        <Routes>
          <Route path="/" element={<Home />} /> {/* Home Page */}
          <Route path="/query" element={<Query />} /> {/* About Page */}
          <Route path="/narrators" element={<NarratorsPage />} /> {/* Narrators Page */}
          <Route path="/book" element={<BookPage />} /> {/* Book Page */}
          <Route path="/reference" element={<ReferencePage />} /> {/* Reference Page */}
          <Route path="/hadith/:hadithId" element={<HadithPage />} />
          <Route path="/narrator/:narratorId" element={<NarratorDetailsPage />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;