import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation

const NarratorsPage = () => {
  const [narrators, setNarrators] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const navigate = useNavigate(); // Initialize useNavigate

  const fetchNarrators = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get('http://localhost:5000/narrators', {
        params: { page },
      });

      setNarrators(response.data.narrators);
      setTotalPages(response.data.totalPages);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Fetch narrators when the page changes
  useEffect(() => {
    fetchNarrators();
  }, [page]);

  const handlePageChange = (newPage) => {
    setNarrators(null)
    setPage(newPage);
  };

  const handleNarratorClick = (narratorId) => {
    navigate(`/narrator/${narratorId}`); // Navigate to NarratorDetailsPage with narratorId
  };

  return (
    <div className="min-h-screen bg-alabaster-500 p-8">
      <h1 className="text-4xl font-bold text-ebony-500 mb-8 text-center">
        Narrators
      </h1>

      {/* Loading and Error Messages */}
      {loading && (
        <div className="text-center text-ebony-500">Loading...</div>
      )}
      {error && (
        <div className="text-center text-red-500">Error: {error}</div>
      )}

      {/* Display Narrators */}
      <div className="space-y-4">
        {narrators?.map((narrator, index) => (
          <div
            key={index}
            className="bg-timberwolf-500 p-6 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow duration-200"
            onClick={() => handleNarratorClick(narrator.narrator.id.low)} // Make narrator clickable
          >
            <p className="text-ebony-500">
              ID: {narrator.narrator.id.low}
            </p>
            <h3 className="text-xl font-bold text-davys_gray-500">
              {narrator.narrator.arabicName}
            </h3>
            <p className="text-ebony-500">
              {narrator.narrator.fullName}
            </p>
            <p className="text-ebony-500">
              <strong>Hadith Count:</strong> {narrator.hadithCount}
            </p>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex flex-wrap justify-center mt-8 gap-2">
          {/* Previous Button */}
          <button
            onClick={() => handlePageChange(page - 1)}
            disabled={page === 1}
            className="px-4 py-2 rounded-lg bg-timberwolf-500 text-ebony-500 hover:bg-cambridge_blue-600 transition-colors duration-200 disabled:opacity-50"
          >
            Previous
          </button>

          {/* Page Buttons */}
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => {
            if (
              pageNum === 1 || // Always show the first page
              pageNum === totalPages || // Always show the last page
              Math.abs(pageNum - page) <= 2 // Show pages around the current page
            ) {
              return (
                <button
                  key={pageNum}
                  onClick={() => handlePageChange(pageNum)}
                  className={`px-4 py-2 rounded-lg ${
                    pageNum === page
                      ? 'bg-cambridge_blue-500 text-alabaster-500'
                      : 'bg-timberwolf-500 text-ebony-500'
                  } hover:bg-cambridge_blue-600 transition-colors duration-200`}
                >
                  {pageNum}
                </button>
              );
            } else if (Math.abs(pageNum - page) === 3) {
              return <span key={pageNum} className="px-4 py-2">...</span>; // Show ellipsis
            }
            return null;
          })}

          {/* Next Button */}
          <button
            onClick={() => handlePageChange(page + 1)}
            disabled={page === totalPages}
            className="px-4 py-2 rounded-lg bg-timberwolf-500 text-ebony-500 hover:bg-cambridge_blue-600 transition-colors duration-200 disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default NarratorsPage;