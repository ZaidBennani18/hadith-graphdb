import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom'; // Import useNavigate for navigation

const NarratorDetailsPage = () => {
  const { narratorId } = useParams();
  const navigate = useNavigate(); // Initialize useNavigate
  const [narrator, setNarrator] = useState(null);
  const [hadiths, setHadiths] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchNarratorDetails = async () => {
      setLoading(true);
      setError(null);

      try {
        // Fetch narrator details
        const narratorResponse = await axios.get(`http://localhost:5000/narrators/${narratorId}`);
        setNarrator(narratorResponse.data);

        // Fetch Hadiths by narrator ID
        const hadithsResponse = await axios.get(`http://localhost:5000/narrators/${narratorId}/hadiths`);
        setHadiths(hadithsResponse.data.hadiths);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchNarratorDetails();
  }, [narratorId]);

  // Handle Hadith click
  const handleHadithClick = (hadithId) => {
    navigate(`/hadith/${hadithId}`); // Navigate to HadithPage with hadithId
  };

  if (loading) {
    return <div className="text-center text-ebony-500">Loading...</div>;
  }

  if (error) {
    return <div className="text-center text-red-500">Error: {error}</div>;
  }

  if (!narrator) {
    return <div className="text-center text-ebony-500">Narrator not found.</div>;
  }

  return (
    <div className="min-h-screen bg-alabaster-500 p-8">
      <h1 className="text-4xl font-bold text-ebony-500 mb-8 text-center">
        Narrator Details
      </h1>

      {/* Narrator Details */}
      <div className="bg-timberwolf-500 p-6 rounded-lg shadow-md mb-8">
        <h3 className="text-xl font-bold text-davys_gray-500">
          {narrator.narrator.arabicName}
        </h3>
        {/* <p className="text-ebony-500">
          <strong>ID:</strong> {narrator.narrator.id.low}
        </p> */}
        <p className="text-ebony-500">
          <strong>Full Name:</strong> {narrator.narrator.fullName}
        </p>
        <p className="text-ebony-500">
          <strong>Hadith Count:</strong> {narrator.hadithCount}
        </p>
        {narrator.narrator.birthDate && (
          <p className="text-ebony-500">
            <strong>Birth Date:</strong> {narrator.narrator.birthDate}
          </p>
        )}
        {narrator.narrator.birthPlace && (
          <p className="text-ebony-500">
            <strong>Place of Birth:</strong> {narrator.narrator.birthPlace}
          </p>
        )}
        {narrator.narrator.placesOfStay && (
          <p className="text-ebony-500">
            <strong>Place of stay:</strong> {narrator.narrator.placesOfStay}
          </p>
        )}
        {narrator.narrator.deathDate && (
          <p className="text-ebony-500">
            <strong>Death Date:</strong> {narrator.narrator.deathDate}
          </p>
        )}
        {narrator.narrator.deathPlace && (
          <p className="text-ebony-500">
            <strong>Place of Death:</strong> {narrator.narrator.deathPlace}
          </p>
        )}
      </div>

      {/* Display Hadiths */}
      <div>
        <h2 className="text-2xl font-bold text-cambridge_blue-500 mb-4">
          Hadiths Narrated by {narrator.narrator.arabicName}
        </h2>
        <div className="space-y-4">
          {hadiths.map((hadith, index) => (
            <div
              key={index}
              className="bg-timberwolf-500 p-6 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow duration-200"
              onClick={() => handleHadithClick(hadith.id.low)} // Make Hadith clickable
            >
              <h3 className="text-xl font-bold text-davys_gray-500">
                Hadith {hadith.id.low}
              </h3>
              <p className="text-ebony-500">
                <strong>Arabic:</strong> {hadith.arabic}
              </p>
              <p className="text-ebony-500">
                <strong>English:</strong> {hadith.english}
              </p>
              <p className="text-ebony-500">
                <strong>Book:</strong> {hadith.book}
              </p>
              {hadith.book_number?<p className="text-ebony-500">
                <strong>Book Number:</strong> {hadith.book_number.low}
              </p>:null}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NarratorDetailsPage;