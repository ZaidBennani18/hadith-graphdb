import React, { useEffect, useState } from 'react';
import axios from 'axios'; // Optional: Use fetch if you prefer

const HomePage = () => {
  const [data, setData] = useState({
    collections: [],
    topNarrators: [],
    totalHadith: 0,
    totalNarrators: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch data from the API
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/');
        setData(response.data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="text-center mt-8 text-ebony-500">Loading...</div>;
  }

  if (error) {
    return <div className="text-center mt-8 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="min-h-screen bg-alabaster-500 p-8">
      <h1 className="text-4xl font-bold text-ebony-500 mb-8 text-center">
        Hadith Database Details
      </h1>

      {/* Display Total Hadith and Narrators */}
      <div className="bg-cambridge_blue-500 p-6 rounded-lg shadow-md mb-12 text-center">
        <h2 className="text-xl font-semibold text-alabaster-500">
          Total Hadith: {data.totalHadith}
        </h2>
        <h2 className="text-xl font-semibold text-alabaster-500">
          Total Narrators: {data.totalNarrators}
        </h2>
      </div>

      {/* Display Collections */}
      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-cambridge_blue-400 mb-4">
          Hadith Collections
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.collections.map((collection, index) => (
            <div
              key={index}
              className="bg-timberwolf-500 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
            >
              <h3 className="text-xl font-bold text-davys_gray-500">
                {collection.collection}
              </h3>
              <p className="text-ebony-500">
                Hadiths: {collection.hadiths}
              </p>
              <p className="text-ebony-500">
                Books: {collection.books}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Display Top Narrators */}
      <section>
        <h2 className="text-2xl font-semibold text-cambridge_blue-400 mb-4">
          Top Narrators
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.topNarrators.map((narrator, index) => (
            <div
              key={index}
              className="bg-timberwolf-500 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
            >
              <h3 className="text-xl font-bold text-davys_gray-500">
                {narrator.narrator.arabicName}
              </h3>
              <p className="text-ebony-500">
                {narrator.narrator.name}
              </p>
              <p className="text-ebony-500">
                Hadith Count: {narrator.hadithCount}
              </p>
             
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage;