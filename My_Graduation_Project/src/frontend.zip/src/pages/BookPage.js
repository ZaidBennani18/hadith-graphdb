import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const BookPage = () => {
  const [book, setBook] = useState("Jami' al-Tirmidhi");
  const [bookNumber, setBookNumber] = useState(1);
  const [hadiths, setHadiths] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  const navigate = useNavigate();

  const books = [
    "Sahih Muslim",
    "Sahih Bukhari",
    "Sunan an-Nasa'i",
    "Sunan Abi Da'ud",
    "Sunan Ibn Majah",
    "Jami' al-Tirmidhi",
  ];

  const fetchHadiths = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get('http://localhost:5000/hadith/book', {
        params: { book, book_number: bookNumber, page },
      });

      setHadiths(response.data.hadiths);
      setTotalPages(response.data.totalPages);
      setHasSearched(true);
    } catch (err) {
      setError(err.message);
      setHasSearched(false);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchHadiths();
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
    fetchHadiths();
  };

  const handleHadithClick = (hadithId) => {
    navigate(`/hadith/${hadithId}`);
  };

  return (
    <div className="min-h-screen bg-alabaster-500 p-8">
      <h1 className="text-4xl font-bold text-ebony-500 mb-8 text-center">
        Search Hadiths by Book
      </h1>

      {/* Search Form */}
      <form onSubmit={handleSearch} className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Book Dropdown */}
          <div>
            <label className="block text-ebony-500 font-semibold mb-2">
              Book
            </label>
            <select
              value={book}
              onChange={(e) => setBook(e.target.value)}
              className="w-full p-2 rounded-lg bg-timberwolf-500 text-ebony-500"
            >
              {books.map((book, index) => (
                <option key={index} value={book}>
                  {book}
                </option>
              ))}
            </select>
          </div>

          {/* Book Number Input */}
          <div>
            <label className="block text-ebony-500 font-semibold mb-2">
              Book Number
            </label>
            <input
              type="number"
              value={bookNumber}
              onChange={(e) => setBookNumber(e.target.value)}
              className="w-full p-2 rounded-lg bg-timberwolf-500 text-ebony-500"
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-4">
          <button
            type="submit"
            className="bg-cambridge_blue-500 text-alabaster-500 px-6 py-2 rounded-lg hover:bg-cambridge_blue-600 transition-colors duration-200"
          >
            Search
          </button>
        </div>
      </form>

      {/* Loading and Error Messages */}
      {loading && (
        <div className="text-center text-ebony-500">Loading...</div>
      )}
      {error && (
        <div className="text-center text-red-500">Error: {error}</div>
      )}

      {/* Display Hadiths */}
      {hasSearched && (
        <div className="space-y-4">
          {hadiths.map((hadith, index) => (
            <div
              key={index}
              className="bg-timberwolf-500 p-6 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow duration-200"
              onClick={() => handleHadithClick(hadith.id.low)}
            >
              <h3 className="text-xl font-bold text-davys_gray-500">
                Hadith {hadith.hadithNumber.low}
              </h3>
              <p className="text-ebony-500">
                <strong>Arabic:</strong> {hadith.arabic}
              </p>
              <p className="text-ebony-500">
                <strong>English:</strong> {hadith.english}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {hasSearched && totalPages > 1 && (
        <div className="flex flex-wrap justify-center mt-8 gap-2">
          {/* Previous Button */}
          <button
            onClick={() => handlePageChange(page - 1)}
            disabled={page === 1}
            className="px-4 py-2 rounded-lg bg-timberwolf-500 text-ebony-500 hover:bg-cambridge_blue-600 transition-colors duration-200 disabled:opacity-50"
          >
            Previous
          </button>

          {/* Page Buttons */}
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => {
            if (
              pageNum === 1 || // Always show the first page
              pageNum === totalPages || // Always show the last page
              Math.abs(pageNum - page) <= 2 // Show pages around the current page
            ) {
              return (
                <button
                  key={pageNum}
                  onClick={() => handlePageChange(pageNum)}
                  className={`px-4 py-2 rounded-lg ${
                    pageNum === page
                      ? 'bg-cambridge_blue-500 text-alabaster-500'
                      : 'bg-timberwolf-500 text-ebony-500'
                  } hover:bg-cambridge_blue-600 transition-colors duration-200`}
                >
                  {pageNum}
                </button>
              );
            } else if (Math.abs(pageNum - page) === 3) {
              return <span key={pageNum} className="px-4 py-2">...</span>; // Show ellipsis
            }
            return null;
          })}

          {/* Next Button */}
          <button
            onClick={() => handlePageChange(page + 1)}
            disabled={page === totalPages}
            className="px-4 py-2 rounded-lg bg-timberwolf-500 text-ebony-500 hover:bg-cambridge_blue-600 transition-colors duration-200 disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default BookPage;