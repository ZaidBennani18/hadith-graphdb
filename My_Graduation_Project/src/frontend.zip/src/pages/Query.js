import React, { useState } from 'react';
import ForceGraph3D from 'react-force-graph-3d';
import axios from 'axios';
import schemaImage from './schema.png'; // Make sure to have this image in your src folder

const Graph = () => {
  const [graphData, setGraphData] = useState(null);
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);
  const [queryHistory, setQueryHistory] = useState([]);
  const [showSchema, setShowSchema] = useState(false);
  const [error, setError] = useState(null);

  const fetchGraphData = async () => {
    if (!query.trim()) {
      setError('Please enter a query');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get('http://localhost:5000/api/query', {
        params: { query }
      });
      
      if (response.data.nodes.length === 0 && response.data.links.length === 0) {
        setError('No data returned for this query');
        setGraphData(null);
      } else {
        setGraphData(response.data);
        setQueryHistory(prev => {
          const newHistory = [query, ...prev.filter(q => q !== query)];
          return newHistory.slice(0, 5);
        });
      }
    } catch (error) {
      const errorMsg = error.response?.data?.error || error.message;
      setError(`Error executing query: ${errorMsg}`);
      setGraphData(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNodeClick = (node) => {
    setSelectedNode(node);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      fetchGraphData();
    }
  };

  return (
    <div className="relative h-screen">
      {/* Error Display */}
      {error && (
        <div className="absolute top-32 right-4 z-20 w-96 bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded shadow-md">
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <span className="font-semibold">Error</span>
            </div>
            <button 
              onClick={() => setError(null)}
              className="text-red-700 hover:text-red-900"
            >
              ×
            </button>
          </div>
          <p className="mt-1 text-sm">{error}</p>
        </div>
      )}

      {/* Query Input */}
      <div className="absolute top-4 right-4 z-10 w-96 bg-timberwolf-500 p-4 rounded-lg shadow-md">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-xl font-bold text-davys_gray-500">Neo4j Query</h3>
          <button 
            onClick={() => setShowSchema(!showSchema)}
            className="text-sm bg-alabaster-500 hover:bg-alabaster-600 text-ebony-500 px-2 py-1 rounded"
          >
            {showSchema ? 'Hide Schema' : 'Show Schema'}
          </button>
        </div>
        
        {showSchema && (
          <div className="mb-2 border border-cambridge_blue-500 rounded p-1">
            <img 
              src={schemaImage} 
              alt="Database Schema" 
              className="w-full h-auto rounded"
            />
            <p className="text-xs text-center text-davys_gray-500 mt-1">Database Schema</p>
          </div>
        )}
        
        <textarea
          className="w-full h-32 p-2 mb-2 text-ebony-500 rounded"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Enter Cypher query (e.g., MATCH (n:Hadith) RETURN n LIMIT 25)"
        />
        
        {queryHistory.length > 0 && (
          <div className="mb-2">
            <p className="text-sm text-davys_gray-500 mb-1">Recent queries:</p>
            <div className="flex flex-wrap gap-1">
              {queryHistory.map((q, i) => (
                <button
                  key={i}
                  className="text-xs bg-alabaster-500 hover:bg-alabaster-600 text-ebony-500 px-2 py-1 rounded"
                  onClick={() => setQuery(q)}
                >
                  {q.length > 30 ? `${q.substring(0, 27)}...` : q}
                </button>
              ))}
            </div>
          </div>
        )}
        
        <button
          className="bg-cambridge_blue-500 hover:bg-cambridge_blue-600 text-white font-bold py-2 px-4 rounded w-full"
          onClick={fetchGraphData}
          disabled={isLoading || !query.trim()}
        >
          {isLoading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Loading...
            </span>
          ) : 'Execute Query'}
        </button>
      </div>

      {/* Graph Container */}
      <div className="w-full h-full">
        {graphData ? (
          graphData.nodes.length > 0 || graphData.links.length > 0 ? (
            <ForceGraph3D
              graphData={graphData}
              nodeLabel="name"
              nodeAutoColorBy="type"
              linkDirectionalArrowLength={3.5}
              linkDirectionalArrowRelPos={1}
              linkCurvature={0.25}
              onNodeClick={handleNodeClick}
              width={window.innerWidth }
              height={window.innerHeight}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-ebony-500 p-4 bg-timberwolf-100 rounded-lg">
                <svg className="w-12 h-12 mx-auto text-davys_gray-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <p className="text-lg font-medium">No data returned</p>
                <p className="text-sm mt-1">Your query didn't return any results</p>
                <button 
                  onClick={() => setQuery('MATCH (n) RETURN n LIMIT 25')}
                  className="mt-3 text-sm bg-cambridge_blue-500 hover:bg-cambridge_blue-600 text-white py-1 px-3 rounded"
                >
                  Try basic query
                </button>
              </div>
            </div>
          )
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-ebony-500">
              <svg className="w-16 h-16 mx-auto text-davys_gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>
              </svg>
              <p className="text-xl font-medium mb-2">Enter a Cypher query to visualize your graph data</p>
             
            </div>
          </div>
        )}
      </div>

      {/* Node Details Overlay */}
      {selectedNode && (
        <div className="absolute top-4 left-4 w-96 bg-timberwolf-500 p-4 rounded-lg shadow-md">
          <div className="flex justify-between items-start">
            <h3 className="text-xl font-bold text-davys_gray-500 mb-2">Node Details</h3>
            <button 
              onClick={() => setSelectedNode(null)}
              className="text-davys_gray-500 hover:text-ebony-500 text-xl"
            >
              ×
            </button>
          </div>
          <div className="space-y-2">
            <p className="text-ebony-500"><strong>Type:</strong> {selectedNode.type}</p>
            {/* <p className="text-ebony-500"><strong>Name:</strong> {selectedNode.name}</p> */}
            <div className="border-t border-cambridge_blue-300 my-2"></div>
            {selectedNode.properties && Object.entries(selectedNode.properties)
              .filter(([key]) => key !== 'id')
              .map(([key, value]) => (
                <div key={key} className="text-ebony-500">
                  <p className="font-medium">{key}:</p>
                  {console.log(value)}
                  <p className="text-sm break-words">{value.low? value.low:value?.toString() || 'N/A'}</p>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Graph;