import React, { useState } from 'react';
import axios from 'axios';
import Graph from '../components/Graph'; 

const ReferencePage = () => {
  const [book, setBook] = useState("Jami' al-Tirmidhi");
  const [hadithNumber, setHadithNumber] = useState(1);
  const [bookNumber, setBookNumber] = useState(1);
  const [hadithData, setHadithData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const books = [
    "Sahih Muslim",
    "Sahih Bukhari",
    "Sunan an-Nasa'i",
    "Sunan Abi Da'ud",
    "Sunan Ibn Majah",
    "Jami' al-Tirmidhi",
  ];

  const fetchHadith = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get(
        `http://localhost:5000/hadith/reference?book=${encodeURIComponent(
          book
        )}&hadithNumber=${hadithNumber}&book_number=${bookNumber}`
      );
      setHadithData(response.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-alabaster-500 p-8">
      <h1 className="text-4xl font-bold text-ebony-500 mb-8 text-center">
        Search Hadith by Reference
      </h1>

      {/* Search Form */}
      <form onSubmit={fetchHadith} className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Book Dropdown */}
          <div>
            <label className="block text-ebony-500 font-semibold mb-2">
              Book
            </label>
            <select
              value={book}
              onChange={(e) => setBook(e.target.value)}
              className="w-full p-2 rounded-lg bg-timberwolf-500 text-ebony-500"
            >
              {books.map((book, index) => (
                <option key={index} value={book}>
                  {book}
                </option>
              ))}
            </select>
          </div>

          {/* Hadith Number Input */}
          <div>
            <label className="block text-ebony-500 font-semibold mb-2">
              Hadith Number
            </label>
            <input
              type="number"
              value={hadithNumber}
              onChange={(e) => setHadithNumber(e.target.value)}
              className="w-full p-2 rounded-lg bg-timberwolf-500 text-ebony-500"
            />
          </div>

          {/* Book Number Input */}
          <div>
            <label className="block text-ebony-500 font-semibold mb-2">
              Book Number
            </label>
            <input
              type="number"
              value={bookNumber}
              onChange={(e) => setBookNumber(e.target.value)}
              className="w-full p-2 rounded-lg bg-timberwolf-500 text-ebony-500"
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-4">
          <button
            type="submit"
            className="bg-cambridge_blue-500 text-alabaster-500 px-6 py-2 rounded-lg hover:bg-cambridge_blue-600 transition-colors duration-200"
          >
            Search
          </button>
        </div>
      </form>

      {/* Loading and Error Messages */}
      {loading && (
        <div className="text-center text-ebony-500">Loading...</div>
      )}
      {error && (
        <div className="text-center text-red-500">Error: {error}</div>
      )}

      {/* Display Hadith Details */}
      {hadithData && (
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-cambridge_blue-500 mb-4">
            Hadith Details
          </h2>
          <div className="bg-timberwolf-500 p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold text-davys_gray-500">
              {hadithData.hadith.book}
            </h3>
            <p className="text-ebony-500">
              <strong>Hadith Number:</strong> {hadithData.hadith.hadithNumber.low}
            </p>
            <p className="text-ebony-500">
              <strong>Book Number:</strong> {hadithData.hadith.book_number.low}
            </p>
            <p className="text-ebony-500">
              <strong>Arabic:</strong> {hadithData.hadith.arabic}
            </p>
            <p className="text-ebony-500">
              <strong>English:</strong> {hadithData.hadith.english}
            </p>
          </div>
        </div>
      )}

      {/* Display Graph */}
      {hadithData?.chain && (
        <div>
          <h2 className="text-2xl font-semibold text-cambridge_blue-500 mb-4">
            Narration Chain
          </h2>
          <Graph graphData={hadithData.chain} />
        </div>
      )}
    </div>
  );
};

export default ReferencePage;