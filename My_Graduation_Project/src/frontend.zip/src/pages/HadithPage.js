import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Graph from '../components/Graph';

const HadithPage = () => {
  const { hadithId } = useParams();
  const [hadith, setHadith] = useState(null);
  const [graphData, setGraphData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchHadithDetails = async () => {
      setLoading(true);
      setError(null);

      try {
        const response = await axios.get(`http://localhost:5000/hadith/${hadithId}`);
        const hadithData = response.data.hadith;
        setGraphData(response.data.chain)
        setHadith(hadithData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchHadithDetails();
  }, [hadithId]);

  if (loading) {
    return <div className="text-center text-ebony-500">Loading...</div>;
  }

  if (error) {
    return <div className="text-center text-red-500">Error: {error}</div>;
  }

  if (!hadith) {
    return <div className="text-center text-ebony-500">Hadith not found.</div>;
  }

  return (
    <div className="min-h-screen bg-alabaster-500 p-8">
      <h1 className="text-4xl font-bold text-ebony-500 mb-8 text-center">
        Hadith Details
      </h1>

      {/* Hadith Details */}
      <div className="bg-timberwolf-500 p-6 rounded-lg shadow-md mb-8">
        <h3 className="text-xl font-bold text-davys_gray-500">
          Hadith {hadith.hadithNumber.low}
        </h3>
        <p className="text-ebony-500">
          <strong>Arabic:</strong> {hadith.arabic}
        </p>
        <p className="text-ebony-500">
          <strong>English:</strong> {hadith.english}
        </p>
        <p className="text-ebony-500">
          <strong>Book:</strong> {hadith.book}
        </p>
        <p className="text-ebony-500">
          <strong>Book Number:</strong> {hadith.book_number.low}
        </p>
      </div>

      {/* Graph */}
      <div className="bg-timberwolf-500 p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-davys_gray-500 mb-4">
          Narration Chain
        </h2>
        <Graph graphData={graphData} /> {/* Pass the chain data to the Graph component */}
      </div>
    </div>
  );
};

export default HadithPage;