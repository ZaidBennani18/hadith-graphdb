import React from 'react';
import { Link } from 'react-router-dom';

const Menu = () => {
  return (
    <div className="bg-davys_gray-500 p-4 shadow-lg">
      <nav className="flex space-x-6 justify-center">
        <Link
          to="/"
          className="text-timberwolf-500 hover:text-cambridge_blue-500 transition-colors duration-200 font-semibold"
        >
          Home
        </Link>
        <Link
          to="/narrators"
          className="text-timberwolf-500 hover:text-cambridge_blue-500 transition-colors duration-200 font-semibold"
        >
          Narrators
        </Link>
        <Link
          to="/book"
          className="text-timberwolf-500 hover:text-cambridge_blue-500 transition-colors duration-200 font-semibold"
        >
          Search by Book
        </Link>
        <Link
          to="/reference"
          className="text-timberwolf-500 hover:text-cambridge_blue-500 transition-colors duration-200 font-semibold"
        >
          Search by Reference Number
        </Link>
        <Link
          to="/query"
          className="text-timberwolf-500 hover:text-cambridge_blue-500 transition-colors duration-200 font-semibold"
        >
          Query Data
        </Link>
      </nav>
    </div>
  );
};

export default Menu;