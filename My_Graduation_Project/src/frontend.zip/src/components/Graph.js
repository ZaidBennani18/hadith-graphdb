import React, { useRef, useEffect, useState } from 'react';
import ForceGraph3D from 'react-force-graph-3d';

const Graph = ({ graphData }) => {
  const graphRef = useRef();
  const [selectedNode, setSelectedNode] = useState(null);


  // If graphData is not provided, show a message
  if (!graphData) {
    return <div className="text-ebony-500">No graph data available.</div>;
  }

  // Handle node click
  const handleNodeClick = (node) => {
    setSelectedNode(node);
  };

  return (
    <div className="relative h-screen">
      {/* Graph Container (Full Screen) */}
      <div className="w-full h-full">
        <ForceGraph3D
          ref={graphRef}
          graphData={graphData}
          nodeLabel="name"
          nodeAutoColorBy="id"
          linkDirectionalArrowLength={3.5}
          linkDirectionalArrowRelPos={1}
          linkCurvature={0.25}
          onNodeClick={handleNodeClick} 
          width={window.innerWidth/1.1} 
          height={window.innerHeight} 
        />
      </div>

      {/* Node Details Overlay (Top-Left Corner) */}
      {selectedNode && (
        <div className="absolute top-4 left-4 w-96 bg-timberwolf-500 p-4 rounded-lg shadow-md">
          <h3 className="text-xl font-bold text-davys_gray-500 mb-4">Node Details</h3>
          <p className="text-ebony-500">
            <strong>ID:</strong> {selectedNode.id}
          </p>
          <p className="text-ebony-500">
            <strong>Name:</strong> {selectedNode.name}
          </p>
          <p className="text-ebony-500">
            <strong>Full Name:</strong> {selectedNode.properties.fullName}
          </p>
          {selectedNode.properties.birthDate && (
            <p className="text-ebony-500">
              <strong>Date of Birth:</strong> {selectedNode.properties.birthDate}
            </p>
          )}
          {selectedNode.properties.birthPlace && (
            <p className="text-ebony-500">
              <strong>Place of Birth:</strong> {selectedNode.properties.birthPlace}
            </p>
          )}
          {selectedNode.properties.placesOfStay && (
            <p className="text-ebony-500">
              <strong>Places of Stay:</strong> {selectedNode.properties.placesOfStay}
            </p>
          )}
          {selectedNode.properties.deathDate && (
            <p className="text-ebony-500">
              <strong>Date of Death:</strong> {selectedNode.properties.deathDate}
            </p>
          )}
          {selectedNode.properties.deathPlace && (
            <p className="text-ebony-500">
              <strong>Place of Death:</strong> {selectedNode.properties.deathPlace}
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default Graph;