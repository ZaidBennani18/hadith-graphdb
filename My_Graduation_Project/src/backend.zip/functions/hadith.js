
const neo4j = require("neo4j-driver");


const driver = neo4j.driver(
    process.env.NEO4J_URI || "bolt://localhost:7687",
    neo4j.auth.basic(process.env.NEO4J_USER || "neo4j", process.env.NEO4J_PASSWORD || "password")
  );
  
  exports.specific_hadith = async (req, res) => {
    const session = driver.session();
    const hadithId = parseInt(req.params.id);
  
    try {
      
      const hadithResult = await session.run(
        `
        MATCH(h:Hadith{id:toInteger($hadithId)})
        RETURN h, h.narrators AS narrators
        `,
        { hadithId }
      );
      if (hadithResult.records.length === 0) {
        return res.status(404).send('Hadith not found');
      }
  
      const hadithNode = hadithResult.records[0].get('h').properties; // Full Hadith node properties
      const narrators = hadithResult.records[0].get('narrators');
  
      // Step 2: Query to get the chain of narrators
      const result = await session.run(
        `
        MATCH (n1:Narrator)-[r:NARRATED_BY {hadith_id: $hadithId}]->(n2:Narrator)
        // WHERE toString(n1.id) IN $narrators AND toString(n2.id) IN $narrators
        RETURN n1 AS n, type(r) AS r, n2 AS m
        ORDER BY n
        `,
        { hadithId: hadithNode.id, narrators }
      );
  
      const nodesMap = new Map();
      const links = [];
  
      result.records.forEach((record) => {
        const n1 = record.get("n").properties; // Extract properties of n1
        const n2 = record.get("m").properties; // Extract properties of n2
  
        if (!nodesMap.has(n1.id.low)) {
          nodesMap.set(n1.id.low, {
            id: n1.id.low,
            name: n1.arabicName,
            label: "Narrator",
            properties: n1,
          });
        }
        if (!nodesMap.has(n2.id.low)) {
          nodesMap.set(n2.id.low, {
            id: n2.id.low,
            name: n2.arabicName,
            label: "Narrator",
            properties: n2,
          });
        }
  
        links.push({ source: n1.id.low, target: n2.id.low }); // Use id.low for source and target
      });
  
      const chain = {
        nodes: Array.from(nodesMap.values()),
        links,
      };
  

      res.json({ chain, hadith: hadithNode });
    } catch (error) {
      console.error("Error fetching data:", error);
      res.status(500).json({ error: "Internal Server Error" });
    } finally {
      await session.close();
    }
  };
  
  exports.specific_hadith_by_reference = async (req, res) => {
    const { book, hadithNumber, book_number } = req.query;
  
    if (!book || !hadithNumber || !book_number) {
      return res.status(400).send('Missing required query parameters: book, hadithNumber, book_number');
    }
  
    const session = driver.session();
  
    try {
      // Step 1: Query to get the whole Hadith node
      const hadithResult = await session.run(
        `
        MATCH (h:Hadith)
        WHERE h.book = $book AND h.hadithNumber = toInteger($hadithNumber) AND h.book_number = toInteger($book_number)
        RETURN h, h.narrators AS narrators
        `,
        { book, hadithNumber: parseInt(hadithNumber), book_number: parseInt(book_number) }
      );
  
      if (hadithResult.records.length === 0) {
        return res.status(404).send('Hadith not found');
      }
  
      const hadithNode = hadithResult.records[0].get('h').properties; // Full Hadith node properties
      const narrators = hadithResult.records[0].get('narrators');
  
      // Step 2: Query to get the chain of narrators
      const result = await session.run(
        `
        MATCH (n1:Narrator)-[r:NARRATED_BY {hadith_id: $hadithId}]->(n2:Narrator)
        // WHERE toString(n1.id) IN $narrators AND toString(n2.id) IN $narrators
        RETURN n1 AS n, type(r) AS r, n2 AS m
        ORDER BY n
        `,
        { hadithId: hadithNode.id, narrators }
      );
  
      const nodesMap = new Map();
      const links = [];
  
      result.records.forEach((record) => {
        const n1 = record.get("n").properties; // Extract properties of n1
        const n2 = record.get("m").properties; // Extract properties of n2
  
        if (!nodesMap.has(n1.id.low)) {
          nodesMap.set(n1.id.low, {
            id: n1.id.low,
            name: n1.arabicName,
            label: "Narrator",
            properties: n1,
          });
        }
        if (!nodesMap.has(n2.id.low)) {
          nodesMap.set(n2.id.low, {
            id: n2.id.low,
            name: n2.arabicName,
            label: "Narrator",
            properties: n2,
          });
        }
  
        links.push({ source: n1.id.low, target: n2.id.low }); // Use id.low for source and target
      });
  
      const chain = {
        nodes: Array.from(nodesMap.values()),
        links,
      };
  
      res.json({ chain, hadith: hadithNode });
    } catch (error) {
      console.error('Error fetching Hadith and chain of narrators:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      await session.close();
    }
  };

  exports.get_hadiths_by_book = async (req, res) => {
    const { book, book_number, page = 1, limit = 10 } = req.query;
  
    if (!book || !book_number) {
      return res.status(400).send('Missing required query parameters: book, book_number');
    }
  
    const session = driver.session();
  
    try {
      // Calculate skip value for pagination
      const skip = (parseInt(page) - 1) * parseInt(limit); // Ensure skip is an integer
  
      // Query to get Hadiths for the specified book and book_number
      const result = await session.run(
        `
        MATCH (h:Hadith)
        WHERE h.book = $book AND h.book_number = toInteger($book_number)
        RETURN h
        ORDER BY h.hadithNumber
        SKIP toInteger($skip)
        LIMIT toInteger($limit)
        `,
        {
          book,
          book_number: parseInt(book_number), // Ensure book_number is an integer
          skip: skip, // skip is already an integer
          limit: parseInt(limit), // Ensure limit is an integer
        }
      );
  
      const hadiths = result.records.map((record) => record.get('h').properties);
  
      // Query to get the total count of Hadiths for the specified book and book_number
      const countResult = await session.run(
        `
        MATCH (h:Hadith)
        WHERE h.book = $book AND h.book_number = toInteger($book_number)
        RETURN COUNT(h) AS total
        `,
        { book, book_number: parseInt(book_number) }
      );
  
      const total = countResult.records[0].get('total').low;
  
      res.json({
        hadiths,
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit)),
      });
    } catch (error) {
      console.error('Error fetching Hadiths:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      await session.close();
    }
  };