
const neo4j = require("neo4j-driver");


const driver = neo4j.driver(
    process.env.NEO4J_URI || "bolt://localhost:7687",
    neo4j.auth.basic(process.env.NEO4J_USER || "neo4j", process.env.NEO4J_PASSWORD || "password")
  );
  

exports.count  =  async (req, res) => {
    const session = driver.session();
  
    try {

        const totalNarratorsResult = await session.run(
            `
            MATCH (n:Narrator)
            RETURN COUNT(n) AS totalNarrators
            `
          );
      
          const totalNarrators = totalNarratorsResult.records[0].get('totalNarrators').toInt();
          const totalHadithResult = await session.run(
            `
            MATCH (n:Hadith)
            RETURN COUNT(n) AS totalHadith
            `
          );
      
          const totalHadith = totalHadithResult.records[0].get('totalHadith').toInt();

      const collectionResult = await session.run(
        `
        MATCH (n:Hadith)
        RETURN n.book AS collection, count(DISTINCT  n.book_number) as books, COUNT(*) AS hadiths
        ORDER BY hadiths DESC
        `
      );
  
      const collections = collectionResult.records.map((record) => ({
        collection: record.get('collection'),
        hadiths: record.get('hadiths').toInt(),
        books: record.get('books').toInt(),
      }));
  
      // Query 2: Top narrators
      const narratorResult = await session.run(
        `
        MATCH (n:Narrator)<-[:NARRATED_BY]-(h:Hadith)
        RETURN n AS narrator, COUNT(h) AS hadithCount
        ORDER BY hadithCount DESC
        LIMIT 9
        `
      );
  
      const narrators = narratorResult.records.map((record) => ({
        narrator: record.get('narrator').properties, // Extract narrator node properties
        hadithCount: record.get('hadithCount').toInt(),
      }));
  
      // Combine and return the results
      res.json({
        collections,
        topNarrators: narrators,
        totalHadith: totalHadith,
        totalNarrators:totalNarrators
      });
    } catch (error) {
      console.error('Error executing queries:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      await session.close();
    }
}


exports.dynamicQuery = async (req, res) => {
  const query = req.query.query;
  if (!query) {
    return res.status(400).json({ error: 'Query parameter is required' });
  }

  const session = driver.session();

  try {
    const result = await session.run(query);
    
    // Transform Neo4j result to graph data format
    const graphData = { nodes: [], links: [] };
    const nodeMap = new Map();

    result.records.forEach(record => {
      // Process all elements in the record
      record.keys.forEach(key => {
        const value = record.get(key);
        
        // Handle nodes
        if (value && value.labels) {
          const labels = value.labels;
          const properties = value.properties || {};
          const nodeType = labels[0] || 'Unknown';
          const nodeId = value.identity.toString();
          
          if (!nodeMap.has(nodeId)) {
            const node = {
              id: nodeId,
              name: properties.name || properties.arabic || properties.english || `Node ${nodeId}`,
              type: nodeType,
              properties: properties
            };
            nodeMap.set(nodeId, node);
            graphData.nodes.push(node);
          }
        }
        console.log(value)
        // Handle relationships
        if (value && value.type) {
          graphData.links.push({
            source: value.start.toString(),
            target: value.end.toString(),
            type: value.type,
            properties: value.properties || {}
          });
        }
      });
    });

    res.json(graphData);
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).json({ 
      error: 'Query execution failed',
      details: error.message 
    });
  } finally {
    await session.close();
  }
};