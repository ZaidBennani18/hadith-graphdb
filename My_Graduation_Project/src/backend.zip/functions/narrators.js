
const neo4j = require("neo4j-driver");


const driver = neo4j.driver(
    process.env.NEO4J_URI || "bolt://localhost:7687",
    neo4j.auth.basic(process.env.NEO4J_USER || "neo4j", process.env.NEO4J_PASSWORD || "password")
  );

exports.get_narrators = async (req, res) => {
    const { page = 1, limit = 10 } = req.query;
  
    const session = driver.session();
  
    try {
      // Calculate skip value for pagination
      const skip = (parseInt(page) - 1) * parseInt(limit);
  
      // Query to get narrators and their Hadith count
      const result = await session.run(
        `
        MATCH (n:Narrator)
        OPTIONAL MATCH(n)-[r:NARRATED_BY]-() 
        RETURN n as narrator, count(DISTINCT r.hadith_id) as hadithCount
        Order by n.id
        SKIP toInteger($skip)
        LIMIT toInteger($limit)
        `,
        { skip: skip, limit: parseInt(limit) }
      );
  
      const narrators = []
       result.records.map((record) => {
        
        const n = record.get("narrator").properties;
        hadithCount =  record.get('hadithCount').low
        narrators.push ({
            "narrator":n,
            "hadithCount":hadithCount
        })
      });
  
      // Query to get the total count of narrators
      const countResult = await session.run(
        `
        MATCH (n:Narrator)
        RETURN COUNT(n) AS total
        `
      );
  
      const total = countResult.records[0].get('total').low;
  
      res.json({
        narrators,
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit)),
      });
    } catch (error) {
      console.error('Error fetching narrators:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      await session.close();
    }
  };


  exports.get_narrator_by_id = async (req, res) => {
    const narratorId = parseInt(req.params.id);
  
    if (!narratorId) {
      return res.status(400).send('Missing required parameter: narratorId');
    }
  
    const session = driver.session();
  
    try {
      const result = await session.run(
        `
        MATCH (n:Narrator {id: toInteger($narratorId)})
        OPTIONAL MATCH(n)-[r:NARRATED_BY]-() 
        RETURN n, count(DISTINCT r.hadith_id) as hadithCount
        `,
        { narratorId: narratorId}
      );
  
      if (result.records.length === 0) {
        return res.status(404).send('Narrator not found');
      }
  
      const narrator = result.records[0].get('n').properties;
      hadithCount =  result.records[0].get('hadithCount').low
      res.json({narrator, hadithCount});
    } catch (error) {
      console.error('Error fetching narrator:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      await session.close();
    }
  };


  exports.get_hadiths_by_narrator_id = async (req, res) => {
    const narratorId = parseInt(req.params.id);

  
    if (!narratorId) {
      return res.status(400).send('Missing required parameter: narratorId');
    }
  
    const session = driver.session();
  
    try {
      const result = await session.run(
        `
        MATCH (n:Narrator {id: toInteger($narratorId)})
        OPTIONAL MATCH (n)-[r:NARRATED_BY]-()
        WITH collect(DISTINCT r.hadith_id) as hadith
        UNWIND hadith as h_id
        MATCH (h:Hadith {id: h_id})
        RETURN h
        `,
        { narratorId: parseInt(narratorId) }
      );
  
      const hadiths = result.records.map((record) => record.get('h').properties);
  
      res.json({ hadiths });
    } catch (error) {
      console.error('Error fetching Hadiths by narrator ID:', error);
      res.status(500).send('Internal Server Error');
    } finally {
      await session.close();
    }
  };