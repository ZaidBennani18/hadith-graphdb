const express = require("express");
const router = express.Router();

const cors = require("cors");
require("dotenv").config();

const hadithRouter = require('./routers/hadithRouter');
const generalRouter = require('./routers/generalRouter');
const narratorRouter = require('./routers/narratorRouter');

const app = express();
app.use(cors());
const PORT = process.env.PORT || 5000;


app.use('/hadith', hadithRouter);
app.use('/narrators', narratorRouter);
app.use('/api', generalRouter);

app.get('/', (req, res) => {
  res.json({ message: "Hadith website Backend" });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
