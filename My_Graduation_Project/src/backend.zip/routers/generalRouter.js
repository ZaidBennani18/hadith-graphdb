const express = require("express");
const router = express.Router();
const sumamry = require('../functions/Summary');

router.get('/', sumamry.count);
router.get('/query', sumamry.dynamicQuery);

module.exports = router;