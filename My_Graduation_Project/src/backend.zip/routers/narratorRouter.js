const express = require("express");
const router = express.Router();
const narrators = require('../functions/narrators');

router.get('/', narrators.get_narrators );
router.get('/:id', narrators.get_narrator_by_id );
router.get('/:id/hadiths', narrators.get_hadiths_by_narrator_id );


module.exports = router;