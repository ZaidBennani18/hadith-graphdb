const express = require("express");
const router = express.Router();
const hadith = require('../functions/hadith');

router.get('/reference', hadith.specific_hadith_by_reference );
router.get('/book', hadith.get_hadiths_by_book );
router.get('/:id', hadith.specific_hadith );


module.exports = router;